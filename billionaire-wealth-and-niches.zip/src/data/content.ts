export interface Niche {
  id: string;
  title: string;
  icon: string;
  image: string;
  description: string;
  potentialEarnings: string;
  examples: BillionaireExample[];
  strategies: string[];
  whyHighPaying: string;
  gettingStarted: string[];
}

export interface BillionaireExample {
  name: string;
  netWorth: string;
  company: string;
  story: string;
}

export interface Step {
  number: number;
  title: string;
  description: string;
  icon: string;
}

export const heroImage = "https://images.pexels.com/photos/36945570/pexels-photo-36945570.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";

export const stepsToWealth: Step[] = [
  {
    number: 1,
    title: "Develop a Wealth Mindset",
    description: "Think abundance, not scarcity. Every billionaire started with a vision that others thought was impossible. Read voraciously, surround yourself with ambitious people, and believe in exponential growth.",
    icon: "Brain",
  },
  {
    number: 2,
    title: "Identify a Massive Problem",
    description: "Billionaires solve problems at scale. Find pain points that affect millions or billions of people. The bigger the problem, the bigger the opportunity. Focus on industries ripe for disruption.",
    icon: "Search",
  },
  {
    number: 3,
    title: "Build Scalable Systems",
    description: "Create business models that can grow without linear increases in cost. Software, platforms, and networks are inherently scalable. Your income should not be tied directly to your time.",
    icon: "Layers",
  },
  {
    number: 4,
    title: "Master Capital & Investment",
    description: "Learn to raise capital, reinvest profits, and make money work for you. Understand compound interest, venture capital, and how to leverage other people's money (OPM) strategically.",
    icon: "TrendingUp",
  },
  {
    number: 5,
    title: "Build an Elite Team",
    description: "No billionaire built their empire alone. Attract A-players, create a culture of excellence, and delegate ruthlessly. Your team's capabilities determine your ceiling.",
    icon: "Users",
  },
  {
    number: 6,
    title: "Execute Relentlessly",
    description: "Ideas are worthless without execution. Move fast, iterate constantly, and outwork your competition. Be prepared to fail multiple times before you succeed at scale.",
    icon: "Rocket",
  },
];

export const niches: Niche[] = [
  {
    id: "tech-ai",
    title: "AI & Technology",
    icon: "Cpu",
    image: "https://images.pexels.com/photos/8849295/pexels-photo-8849295.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Artificial Intelligence and cutting-edge technology represent the fastest-growing wealth creation opportunity in human history. From machine learning to autonomous systems, this niche is creating billionaires at an unprecedented rate.",
    potentialEarnings: "$500K - $10B+",
    examples: [
      {
        name: "Jensen Huang",
        netWorth: "$106B",
        company: "NVIDIA",
        story: "Founded NVIDIA in 1993 focusing on GPU technology. His early bet on AI computing chips made NVIDIA the backbone of the AI revolution, transforming a gaming chip company into the most valuable company on Earth.",
      },
      {
        name: "Sam Altman",
        netWorth: "$1B+",
        company: "OpenAI",
        story: "Led OpenAI from a research lab to the fastest-growing tech company ever with ChatGPT. Demonstrated that AI products can achieve mass adoption almost overnight.",
      },
      {
        name: "Elon Musk",
        netWorth: "$230B+",
        company: "Tesla, SpaceX, xAI",
        story: "Built multiple billion-dollar companies across electric vehicles, space exploration, and now AI. Proves that technology visionaries who execute can build unprecedented wealth.",
      },
    ],
    strategies: [
      "Build AI-powered SaaS products that solve enterprise problems",
      "Create AI tools for specific industry verticals (healthcare, legal, finance)",
      "Develop and license proprietary AI models and datasets",
      "Build AI infrastructure and developer tools",
      "Create AI-enhanced consumer products and apps",
    ],
    whyHighPaying: "AI is projected to add $15.7 trillion to the global economy by 2030. Companies are desperate for AI solutions and willing to pay premium prices. The barrier to entry is high (requiring deep expertise), which limits competition and keeps margins fat.",
    gettingStarted: [
      "Learn Python, machine learning, and deep learning fundamentals",
      "Build projects using OpenAI API, Hugging Face, and cloud AI services",
      "Identify an industry you know well and find AI-solvable problems",
      "Start with consulting/services, then productize your solutions",
      "Raise seed funding or bootstrap with early customer revenue",
    ],
  },
  {
    id: "fintech",
    title: "Finance & FinTech",
    icon: "DollarSign",
    image: "https://images.pexels.com/photos/6770610/pexels-photo-6770610.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Financial technology is disrupting traditional banking, investing, and payment systems. From cryptocurrency to algorithmic trading, this niche offers massive opportunities for wealth creation through innovation in how money moves.",
    potentialEarnings: "$300K - $5B+",
    examples: [
      {
        name: "Changpeng Zhao (CZ)",
        netWorth: "$33B",
        company: "Binance",
        story: "Built Binance into the world's largest crypto exchange in just 180 days. Started with $15M ICO funding and grew it into a company processing billions in daily trading volume.",
      },
      {
        name: "Patrick Collison",
        netWorth: "$11.5B",
        company: "Stripe",
        story: "Co-founded Stripe at age 19 with his brother. Simplified online payments for businesses and grew Stripe into a $95B company that processes hundreds of billions in transactions.",
      },
      {
        name: "Brian Armstrong",
        netWorth: "$11B",
        company: "Coinbase",
        story: "Founded Coinbase in 2012 to make cryptocurrency accessible to everyone. Took the company public in 2021, becoming the first major crypto company to list on NASDAQ.",
      },
    ],
    strategies: [
      "Build payment processing solutions for underserved markets",
      "Create algorithmic trading and robo-advisory platforms",
      "Develop blockchain/DeFi protocols and applications",
      "Build embedded finance solutions for non-financial companies",
      "Create financial literacy and wealth management tools",
    ],
    whyHighPaying: "The global financial services market is worth $26 trillion. FinTech companies can capture even tiny percentages of transaction flows to generate massive revenue. Recurring revenue models in finance create extremely valuable businesses.",
    gettingStarted: [
      "Get deep knowledge of financial regulations (SEC, banking laws)",
      "Learn blockchain development and smart contract programming",
      "Understand payment processing infrastructure (ACH, SWIFT, APIs)",
      "Build a prototype solving a specific financial pain point",
      "Partner with established banks for regulatory compliance",
    ],
  },
  {
    id: "real-estate",
    title: "Real Estate & PropTech",
    icon: "Building",
    image: "https://images.pexels.com/photos/943089/pexels-photo-943089.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Real estate has created more millionaires and billionaires than any other industry. Combined with technology (PropTech), modern real estate opportunities range from traditional investing to innovative platforms that democratize property access.",
    potentialEarnings: "$200K - $20B+",
    examples: [
      {
        name: "Donald Bren",
        netWorth: "$17B",
        company: "Irvine Company",
        story: "Built the Irvine Company into a real estate empire owning 126M+ sq ft of property across California. Focused on master-planned communities and commercial real estate.",
      },
      {
        name: "Stephen Ross",
        netWorth: "$12.4B",
        company: "Related Companies",
        story: "Developed Hudson Yards, the largest private real estate development in US history ($25B project). Built wealth through mega-scale mixed-use developments.",
      },
      {
        name: "Robert Reffkin",
        netWorth: "$500M+",
        company: "Compass",
        story: "Founded Compass to bring technology to real estate brokerage. Raised over $1.5B in funding and disrupted the traditional real estate agent model.",
      },
    ],
    strategies: [
      "Invest in multi-family properties with value-add renovations",
      "Build PropTech platforms (listing sites, management tools, marketplaces)",
      "Develop commercial real estate in growing metropolitan areas",
      "Create real estate crowdfunding or fractional ownership platforms",
      "Build short-term rental empires using data-driven property selection",
    ],
    whyHighPaying: "Real estate is a $326 trillion global asset class. It offers leverage (mortgages), tax advantages (depreciation, 1031 exchanges), appreciation, and cash flow. Technology is only beginning to transform this traditionally analog industry.",
    gettingStarted: [
      "Start with a single rental property using FHA loan (3.5% down)",
      "Learn property analysis, cap rates, and cash-on-cash returns",
      "Network with successful real estate investors in your market",
      "Use house hacking (live in one unit, rent others) to start free",
      "Scale through BRRRR strategy (Buy, Rehab, Rent, Refinance, Repeat)",
    ],
  },
  {
    id: "ecommerce",
    title: "E-Commerce & DTC Brands",
    icon: "ShoppingCart",
    image: "https://images.pexels.com/photos/5632391/pexels-photo-5632391.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "E-commerce is reshaping global retail. Direct-to-consumer (DTC) brands are cutting out middlemen and building billion-dollar companies. From Amazon FBA to Shopify stores, the digital marketplace offers unlimited earning potential.",
    potentialEarnings: "$100K - $5B+",
    examples: [
      {
        name: "Jeff Bezos",
        netWorth: "$200B+",
        company: "Amazon",
        story: "Started selling books online from his garage in 1994. Built Amazon into the everything store, then expanded into cloud computing, streaming, and logistics to become one of the wealthiest humans ever.",
      },
      {
        name: "Tobias Lütke",
        netWorth: "$9B",
        company: "Shopify",
        story: "Built Shopify after trying to sell snowboards online and finding existing tools inadequate. Created a platform that now powers millions of online stores worldwide.",
      },
      {
        name: "Emily Weiss",
        netWorth: "$400M+",
        company: "Glossier",
        story: "Turned a beauty blog into Glossier, a DTC beauty brand valued at $1.8B. Proved that community-driven brands can disrupt established beauty conglomerates.",
      },
    ],
    strategies: [
      "Build a DTC brand in a passionate niche (beauty, fitness, pets)",
      "Create an Amazon FBA business with private-label products",
      "Build a B2B e-commerce marketplace for a specific industry",
      "Develop subscription box services with high retention",
      "Create e-commerce enablement tools and SaaS platforms",
    ],
    whyHighPaying: "Global e-commerce sales surpassed $6 trillion. DTC brands capture 60-80% margins vs. 30-40% through retailers. Digital distribution eliminates geographic limitations. Subscription models create predictable recurring revenue.",
    gettingStarted: [
      "Research trending products using tools like Jungle Scout or Helium 10",
      "Start a Shopify store or Amazon FBA business with <$5K",
      "Master Facebook/Instagram ads and influencer marketing",
      "Focus on one product category and dominate it completely",
      "Reinvest profits into inventory and marketing to scale aggressively",
    ],
  },
  {
    id: "biotech",
    title: "Healthcare & Biotech",
    icon: "Heart",
    image: "https://images.pexels.com/photos/9574516/pexels-photo-9574516.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Healthcare and biotechnology innovations save lives and generate extraordinary returns. From drug development to medical devices and digital health, this niche combines purpose with massive financial opportunity.",
    potentialEarnings: "$400K - $15B+",
    examples: [
      {
        name: "Stéphane Bancel",
        netWorth: "$6B",
        company: "Moderna",
        story: "Led Moderna from a struggling biotech startup to a COVID-19 vaccine powerhouse. The company's mRNA technology platform is now being applied to cancer, flu, and dozens of other diseases.",
      },
      {
        name: "Patrick Soon-Shiong",
        netWorth: "$7.5B",
        company: "NantHealth/Abraxis",
        story: "Developed Abraxane, a revolutionary cancer drug, and sold Abraxis to Celgene for $2.9B. Now pioneering personalized cancer immunotherapy treatments.",
      },
      {
        name: "Anne Wojcicki",
        netWorth: "$800M",
        company: "23andMe",
        story: "Founded 23andMe to make genetic testing accessible. Built a database of 12M+ genotyped customers and leveraged genetic data for drug discovery partnerships.",
      },
    ],
    strategies: [
      "Develop digital health and telemedicine platforms",
      "Create AI-powered diagnostic and drug discovery tools",
      "Build health & wellness DTC brands (supplements, devices)",
      "Invest in or found biotech startups targeting unmet medical needs",
      "Create healthcare SaaS (EHR, practice management, billing)",
    ],
    whyHighPaying: "Global healthcare spending exceeds $10 trillion annually. Biotech companies can achieve 90%+ margins on patented drugs. An aging population and pandemic preparedness are driving unprecedented investment. Healthcare is recession-proof.",
    gettingStarted: [
      "Get domain expertise (MD, PhD, or partner with scientists)",
      "Identify unmet medical needs with large addressable markets",
      "Apply for NIH/SBIR grants for non-dilutive early funding",
      "Build relationships with pharma companies for partnerships",
      "Consider digital health platforms with lower regulatory barriers",
    ],
  },
  {
    id: "saas",
    title: "SaaS & Cloud Computing",
    icon: "Cloud",
    image: "https://images.pexels.com/photos/7413915/pexels-photo-7413915.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    description: "Software-as-a-Service businesses generate recurring revenue, scale infinitely, and command the highest valuations in tech. Cloud computing infrastructure continues to grow at 20%+ annually, creating enormous opportunities.",
    potentialEarnings: "$200K - $50B+",
    examples: [
      {
        name: "Marc Benioff",
        netWorth: "$7.5B",
        company: "Salesforce",
        story: "Pioneered the SaaS model with Salesforce CRM in 1999. Proved that cloud-based software could replace on-premise enterprise software. Built Salesforce into a $200B+ company.",
      },
      {
        name: "Zoom's Eric Yuan",
        netWorth: "$4.5B",
        company: "Zoom",
        story: "Built Zoom after being frustrated with existing video conferencing tools at Cisco. Created a product so good it became a verb. Revenue went from $623M to $4B in one year during COVID.",
      },
      {
        name: "Tope Awotona",
        netWorth: "$1.4B",
        company: "Calendly",
        story: "Nigerian immigrant who invested his life savings to build Calendly. Bootstrapped to profitability before raising capital, eventually reaching a $3B valuation for a scheduling tool.",
      },
    ],
    strategies: [
      "Build vertical SaaS for specific industries (legal, dental, construction)",
      "Create micro-SaaS products solving narrow problems perfectly",
      "Build API-first platforms that other developers integrate with",
      "Create no-code/low-code tools for non-technical users",
      "Build AI-enhanced productivity and workflow automation tools",
    ],
    whyHighPaying: "SaaS companies trade at 10-30x revenue multiples. Monthly recurring revenue (MRR) creates predictable, compounding growth. Gross margins of 70-90% are standard. Low marginal cost per customer enables massive scale.",
    gettingStarted: [
      "Learn to code or find a technical co-founder",
      "Talk to 100 potential customers before writing any code",
      "Build an MVP (Minimum Viable Product) in 30-60 days",
      "Price based on value, not cost (most SaaS is underpriced)",
      "Focus on reducing churn — retention is everything in SaaS",
    ],
  },
];

export const wealthPrinciples = [
  {
    title: "Think in Decades, Not Days",
    description: "Billionaires play long-term games. Jeff Bezos didn't take a salary for years. Warren Buffett made 99% of his wealth after age 50. Patience combined with consistent action creates exponential results.",
    icon: "Clock",
  },
  {
    title: "Own Equity, Not Just Income",
    description: "You cannot become a billionaire on salary alone. You must own equity in something that scales — a company, real estate portfolio, or investment portfolio. Ownership is the key to asymmetric wealth creation.",
    icon: "Key",
  },
  {
    title: "Leverage Technology & People",
    description: "Use technology to serve millions. Hire people who are better than you. Create systems that generate value while you sleep. Leverage is the multiplier that turns hard work into extraordinary outcomes.",
    icon: "Zap",
  },
  {
    title: "Embrace Calculated Risk",
    description: "Every billionaire took risks others wouldn't. But these are calculated risks — thorough research, diversification, and understanding the downside. Risk is not reckless; it's strategic.",
    icon: "Target",
  },
  {
    title: "Create Multiple Income Streams",
    description: "Diversify your revenue sources. Build businesses, invest in stocks, own real estate, create intellectual property. Multiple streams of income provide security and accelerate wealth accumulation.",
    icon: "GitBranch",
  },
  {
    title: "Network is Net Worth",
    description: "Your relationships determine your opportunities. Every billionaire has a powerful network. Attend events, provide value to others first, and cultivate relationships with people who are where you want to be.",
    icon: "Network",
  },
];
