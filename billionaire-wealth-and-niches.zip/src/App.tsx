import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import StepsSection from "./components/StepsSection";
import PrinciplesSection from "./components/PrinciplesSection";
import NichesSection from "./components/NichesSection";
import ComparisonSection from "./components/ComparisonSection";
import GallerySection from "./components/GallerySection";
import DownloadSection from "./components/DownloadSection";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar />
      <HeroSection />
      <StepsSection />
      <PrinciplesSection />
      <NichesSection />
      <ComparisonSection />
      <GallerySection />
      <DownloadSection />
      <Footer />
    </div>
  );
}
