import { useState, useEffect } from "react";
import { Crown, Download, Menu, X } from "lucide-react";
import { generateBillionairePdf } from "../utils/generatePdf";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await generateBillionairePdf();
    } catch (e) {
      console.error(e);
    }
    setDownloading(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-gray-950/90 backdrop-blur-xl border-b border-gray-800/50 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-lg flex items-center justify-center">
            <Crown className="w-5 h-5 text-gray-900" />
          </div>
          <span className="text-white font-bold text-lg hidden sm:block">
            Billionaire Blueprint
          </span>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-6">
          <a href="#steps" className="text-gray-400 text-sm hover:text-amber-400 transition-colors">Steps</a>
          <a href="#niches" className="text-gray-400 text-sm hover:text-amber-400 transition-colors">Niches</a>
          <a href="#principles" className="text-gray-400 text-sm hover:text-amber-400 transition-colors">Principles</a>
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-gray-900 font-bold px-5 py-2.5 rounded-lg text-sm hover:from-amber-400 hover:to-yellow-400 transition-all disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            {downloading ? "Generating..." : "Download PDF"}
          </button>
        </div>

        {/* Mobile menu button */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="md:hidden text-gray-400 hover:text-white"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-gray-950/95 backdrop-blur-xl border-b border-gray-800 p-4 space-y-3">
          <a href="#steps" onClick={() => setMobileOpen(false)} className="block text-gray-300 py-2 hover:text-amber-400">Steps</a>
          <a href="#niches" onClick={() => setMobileOpen(false)} className="block text-gray-300 py-2 hover:text-amber-400">Niches</a>
          <a href="#principles" onClick={() => setMobileOpen(false)} className="block text-gray-300 py-2 hover:text-amber-400">Principles</a>
          <button
            onClick={() => { handleDownload(); setMobileOpen(false); }}
            disabled={downloading}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-gray-900 font-bold px-5 py-3 rounded-lg text-sm"
          >
            <Download className="w-4 h-4" />
            {downloading ? "Generating..." : "Download PDF"}
          </button>
        </div>
      )}
    </nav>
  );
}
