import { Crown } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-950 border-t border-gray-800 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-yellow-600 rounded-xl flex items-center justify-center">
              <Crown className="w-5 h-5 text-gray-900" />
            </div>
            <div>
              <span className="text-white font-bold text-lg">Billionaire Blueprint</span>
              <p className="text-gray-500 text-xs">Your guide to extraordinary wealth</p>
            </div>
          </div>

          <div className="flex items-center gap-8 text-sm text-gray-500">
            <a href="#steps" className="hover:text-amber-400 transition-colors">Steps</a>
            <a href="#niches" className="hover:text-amber-400 transition-colors">Niches</a>
            <a href="#principles" className="hover:text-amber-400 transition-colors">Principles</a>
            <a href="#download" className="hover:text-amber-400 transition-colors">Download PDF</a>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-800/50 text-center">
          <p className="text-gray-600 text-sm">
            © {new Date().getFullYear()} Billionaire Blueprint. For educational purposes only. 
            Not financial advice. All billionaire data sourced from public records.
          </p>
        </div>
      </div>
    </footer>
  );
}
